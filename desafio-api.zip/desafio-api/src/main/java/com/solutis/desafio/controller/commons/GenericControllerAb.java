package com.solutis.desafio.controller.commons;

import java.io.Serializable;

public abstract class GenericControllerAb implements Serializable {

	private static final long serialVersionUID = 1797520628248164550L;

}
