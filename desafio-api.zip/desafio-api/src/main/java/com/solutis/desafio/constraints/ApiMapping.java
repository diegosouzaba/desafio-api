package com.solutis.desafio.constraints;

public class ApiMapping {

	public static final String API_MAPPING = "desafio-solutis/api/v1";

}
